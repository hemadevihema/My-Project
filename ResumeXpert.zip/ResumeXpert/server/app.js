const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const path = require("path");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());

// ✅ FIX: Allow frontend requests (Live Server + Dev Server)
app.use(cors({
  origin: ["http://127.0.0.1:5501", "http://localhost:5000"],
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true
}));

// ✅ Serve static frontend files
app.use(express.static(path.join(__dirname, "../public")));

// ✅ Fix: Serve dashboard.html correctly
app.get("/user/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/dashboard.html"));
});

// ✅ Fix: Serve create-resume.html correctly
app.get("/user/create-resume", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/create-resume.html"));
});

// ✅ Optional: Serve index.html if needed
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.error("❌ MongoDB Connection Error:", err));

// Routes
const authRoutes = require("./routes/auth");
const resumeRoutes = require("./routes/resumes");

app.use("/api/auth", authRoutes);
app.use("/api/resumes", resumeRoutes);

// Start server
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
