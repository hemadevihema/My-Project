const mongoose = require('mongoose');

const resumeSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
  },
  personalDetails: {
    type: Object,
    required: true,
  },
  education: {
    type: Array,
    default: [],
  },
  experience: {
    type: Array,
    default: [],
  },
  skills: {
    type: Array,
    default: [],
  },
  projects: {
    type: Array,
    default: [],
  },
  awards: {
    type: Array,
    default: [],
  },
});

const Resume = mongoose.model('Resume', resumeSchema);
module.exports = Resume;
