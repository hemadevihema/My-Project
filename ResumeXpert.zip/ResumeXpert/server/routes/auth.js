const express = require('express');
const router = express.Router();
const path = require("path");

// Dummy authentication logic for now, since Firebase is handled on the frontend
router.post("/register", (req, res) => {
  const { email, password } = req.body;
  res.status(201).json({ message: "Account created successfully!" });
});

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  res.status(200).json({ message: "Login successful!" });
});

// ✅ New Route: Serve Dashboard Page
router.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "../../public/dashboard.html")); // ✅ Serves the dashboard page
});

module.exports = router;
