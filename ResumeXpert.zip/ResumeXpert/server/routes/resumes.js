const express = require("express");
const Resume = require("../models/Resume");

const router = express.Router();

// GET Resumes by User ID (Allow multiple resumes per user)
router.get("/user/:userId", async (req, res) => {
    try {
        const resumes = await Resume.find({ userId: req.params.userId });

        if (!resumes || resumes.length === 0) {
            return res.status(404).json({ message: "No resumes found for this user" });
        }

        res.json(resumes); // Return all resumes for the user
    } catch (error) {
        res.status(500).json({ message: "Error fetching resumes" });
    }
});

// POST or UPDATE Resume (Create or update multiple resumes per user)
router.post("/", async (req, res) => {
    try {
        const { userId, title, personalDetails, education, experience } = req.body;

        // Creating a new resume
        const newResume = new Resume({
            userId,
            title,
            personalDetails,
            education,
            experience,
            // Add more fields as necessary
        });

        const savedResume = await newResume.save();
        res.status(201).json({ message: "Resume created", resume: savedResume });

    } catch (error) {
        console.error("Error saving resume:", error);
        res.status(500).json({ message: "Error saving resume" });
    }
});

module.exports = router;
