// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";

// Firebase configuration (Replace with your own credentials)
const firebaseConfig = {
  apiKey: "AIzaSyBAHezYA1xHLwXHriK1h_r1BE4rLKBLOiM",
  authDomain: "weatherapp-4f535.firebaseapp.com",
  projectId: "weatherapp-4f535",
  storageBucket: "weatherapp-4f535.firebasestorage.app",
  messagingSenderId: "625745060810",
  appId: "1:625745060810:web:445630436aac18fa412533",
  measurementId: "G-4038K1NZLQ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// DOM Elements
const signUp = document.getElementById("signUp");
const signIn = document.getElementById("login");
const register = document.getElementsByClassName("register")[0];
const login = document.getElementsByClassName("login")[0];
const head = document.getElementsByClassName("head")[0];
const signUpBtn = document.getElementById("signUpBtn");
const loginBtn = document.getElementById("loginBtn");

// Function to show messages
function showMessage(message, divId) {
  var messageDiv = document.getElementById(divId);
  messageDiv.style.display = "block";
  messageDiv.innerHTML = message;
  messageDiv.style.opacity = 1;
  setTimeout(() => {
    messageDiv.style.opacity = 0;
    messageDiv.style.display = "none";
  }, 2500);
}

// **SIGN-UP FUNCTION**
signUp.addEventListener("click", (event) => {
  event.preventDefault();
  const email = document.getElementById("remail").value.trim();
  const password = document.getElementById("rpassword").value.trim();

  if (!email || !password) {
    showMessage("Email & Password are required!", "signUpMessage");
    return;
  }

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredentials) => {
      const user = userCredentials.user;
      showMessage("Account created successfully!", "signUpMessage");

      // Redirect to backend dashboard
      setTimeout(() => {
        window.location.href = `http://localhost:5000/user/dashboard?uid=${user.uid}`;
      }, 2000);
    })
    .catch((error) => {
      console.error("Signup Error:", error);
      if (error.code === "auth/email-already-in-use") {
        showMessage("Email already exists!", "signUpMessage");
      } else if (error.code === "auth/weak-password") {
        showMessage("Password should be at least 6 characters!", "signUpMessage");
      } else {
        showMessage("Signup failed. Try again!", "signUpMessage");
      }
    });
});

// **LOGIN FUNCTION**
signIn.addEventListener("click", (event) => {
  event.preventDefault();
  const email = document.getElementById("lemail").value.trim();
  const password = document.getElementById("lpassword").value.trim();

  if (!email || !password) {
    showMessage("Email & Password are required!", "signUpMessage");
    return;
  }

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredentials) => {
      const user = userCredentials.user;
      showMessage("Login Successful!", "signUpMessage");

      // Store user ID in local storage
      localStorage.setItem("loggedInUserId", user.uid);

      // Redirect to backend dashboard
      setTimeout(() => {
        window.location.href = `http://localhost:5000/user/dashboard?uid=${user.uid}`;
      }, 2000);
    })
    .catch((error) => {
      console.error("Login Error:", error);
      if (error.code === "auth/invalid-credential") {
        showMessage("Incorrect Email or Password!", "signUpMessage");
      } else {
        showMessage("Login failed. Check credentials!", "signUpMessage");
      }
    });
});

// Toggle between login and signup forms
signUpBtn.addEventListener("click", () => {
  register.style.display = "block";
  login.style.display = "none";
  head.innerHTML = "<h2>Sign Up</h2>";
});

loginBtn.addEventListener("click", () => {
  login.style.display = "block";
  register.style.display = "none";
  head.innerHTML = "<h2>Login</h2>";
});
