/* <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Build Your Resume</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        /* Existing styles remain unchanged */
    </style>
</head>
<body>
    <nav class="gradient-nav">
        <h1>Build Your Master Resume</h1>
        <div>
            <button id="saveBtn">Save Draft</button>
            <button id="downloadBtn">Download PDF</button>
            <button id="aiGenerate" style="background: #f59e0b;">AI Enhance</button>
        </div>
    </nav>

    <div class="resume-builder">
        <!-- Personal Information -->
        <div class="section-card">
            <h3>Personal Information</h3>
            <div class="form-grid">
                <input type="text" placeholder="Full Name" id="name">
                <input type="email" placeholder="Email" id="email">
            </div>
        </div>

        <!-- Education -->
        <div class="section-card">
            <h3>Education</h3>
            <div id="education-section">
                <input type="text" class="education-input" placeholder="Degree, University, Year">
            </div>
            <button onclick="addField('education-section', 'education-input')">+ Add More</button>
        </div>

        <!-- Experience -->
        <div class="section-card">
            <h3>Experience</h3>
            <div id="experience-section">
                <input type="text" class="experience-input" placeholder="Job Title, Company, Years">
            </div>
            <button onclick="addField('experience-section', 'experience-input')">+ Add More</button>
        </div>

        <!-- Skills -->
        <div class="section-card">
            <h3>Skills</h3>
            <div id="skills-section">
                <input type="text" class="skills-input" placeholder="Skill">
            </div>
            <button onclick="addField('skills-section', 'skills-input')">+ Add More</button>
        </div>

        <!-- Projects -->
        <div class="section-card">
            <h3>Projects</h3>
            <div id="projects-section">
                <input type="text" class="projects-input" placeholder="Project Name, Description">
            </div>
            <button onclick="addField('projects-section', 'projects-input')">+ Add More</button>
        </div>

        <!-- Awards -->
        <div class="section-card">
            <h3>Awards</h3>
            <div id="awards-section">
                <input type="text" class="awards-input" placeholder="Award Title, Year">
            </div>
            <button onclick="addField('awards-section', 'awards-input')">+ Add More</button>
        </div>

        <!-- AI-Enhanced Resume Output -->
        <div class="section-card">
            <h3>AI Enhanced Resume</h3>
            <div id="ai-output">Your AI-enhanced resume will appear here.</div>
        </div>
    </div>

    <!-- Chatbot Icon -->
    <button class="chatbot-btn" onclick="toggleChatbot()">
        <img src="/images/CHATBOT.png" alt="Chatbot">
    </button>

    <!-- Chatbot Window -->
    <div class="chatbot-window" id="chatbot">
        <h4>AI Chatbot</h4>
        <p>Ask me anything about resumes!</p>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
    <script>
        function addField(sectionId, className) {
            const section = document.getElementById(sectionId);
            const input = document.createElement("input");
            input.type = "text";
            input.className = className;
            input.placeholder = "Add more...";
            section.appendChild(input);
        }

        function toggleChatbot() {
            const chatbot = document.getElementById("chatbot");
            chatbot.style.display = chatbot.style.display === "block" ? "none" : "block";
        }

        // Function to generate the resume using data
        async function generateResume() {
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const education = Array.from(document.querySelectorAll('.education-input')).map(input => input.value).join(", ");
            const experience = Array.from(document.querySelectorAll('.experience-input')).map(input => input.value).join(", ");
            const skills = Array.from(document.querySelectorAll('.skills-input')).map(input => input.value).join(", ");
            const projects = Array.from(document.querySelectorAll('.projects-input')).map(input => input.value).join(", ");
            const awards = Array.from(document.querySelectorAll('.awards-input')).map(input => input.value).join(", ");

            const resumeData = {
                name,
                email,
                education,
                experience,
                skills,
                projects,
                awards
            };

            // Send data to backend for AI enhancement
            try {
                const response = await fetch('/api/resumes/ai-enhance', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(resumeData)
                });

                const data = await response.json();
                if (data.success) {
                    // Display enhanced resume
                    document.getElementById('ai-output').innerHTML = data.enhancedResume;
                } else {
                    document.getElementById('ai-output').innerHTML = "Error generating resume. Please try again!";
                }
            } catch (error) {
                document.getElementById('ai-output').innerHTML = "An error occurred. Please try again!";
            }
        }

        // Download the generated resume as PDF
        document.getElementById('downloadBtn').addEventListener('click', () => {
            const element = document.getElementById('ai-output');
            html2pdf(element, {
                filename: 'generated_resume.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 4 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            });
        });

        // AI Enhance button triggers the resume generation
        document.getElementById('aiGenerate').addEventListener('click', generateResume);
    </script>
</body>
</html>
 */