document.addEventListener("DOMContentLoaded", async () => {
    const userId = new URLSearchParams(window.location.search).get("uid");

    // If no userId is found, redirect directly to the create-resume page.
    if (!userId) {
        alert("lets create a new resume");
        window.location.href = "/user/create-resume";
        return; // Exit the script
    }

    console.log("🔹 Logged in User ID:", userId);

    const container = document.querySelector(".dashboard-grid");
    const template = document.getElementById("resumeTemplate");

    try {
        const response = await fetch(`/api/resumes/user/${userId}`);
        const resumes = await response.json();

        // If no resumes are found, log it and continue (but do not break the process).
        if (!resumes.length) {
            console.log("ℹ️ No resumes found for this user.");
        }

        // Loop through the resumes and display them
        resumes.forEach((resume) => {
            const clone = template.cloneNode(true);
            clone.style.display = "block";

            // Properly set resume title & last updated date
            clone.querySelector(".resume-title").textContent = resume.title || "Untitled Resume";
            clone.querySelector(".last-updated span").textContent = 
                resume.updatedAt ? new Date(resume.updatedAt).toLocaleDateString() : "N/A";

            // Edit Button → Redirect to resume builder
            clone.querySelector(".edit-btn").addEventListener("click", () => {
                window.location.href = `/user/create-resume?uid=${userId}&resumeId=${resume._id}`;
            });

            // Download Button → Triggers PDF download
            clone.querySelector(".download-btn").addEventListener("click", () => {
                window.open(`/api/resumes/download/${resume._id}`, "_blank");
            });

            // Append the new resume to the container
            container.appendChild(clone);
        });

    } catch (error) {
        // If the fetch request fails, log the error and directly redirect
        console.error("❌ Error fetching resumes:", error);
        alert("Failed to load resumes. Redirecting to Create Resume...");
        window.location.href = "/user/create-resume"; // Redirect if there is an error
    }
});